package internal

// SignIn sign in to your email
func SignIn() {
	// WIP
}

// Send send email
func Send(to, from, message string) {
	// WIP
}
