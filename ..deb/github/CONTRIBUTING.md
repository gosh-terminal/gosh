# Welcome to gosh!

For speedy contributions open it in Gitpod, gosh will be pre-installed with the
latest build in a VSCode like editor all from your browser.

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/JesterOrNot/gosh)

File an issue or request more features here on
[GitHub](https://github.com/JesterOrNot/gosh/issues/new/choose)!

**Working on your first Pull Request?** You can learn how from this *free* series [How to Contribute to an Open Source Project on GitHub](https://egghead.io/series/how-to-contribute-to-an-open-source-project-on-github)
